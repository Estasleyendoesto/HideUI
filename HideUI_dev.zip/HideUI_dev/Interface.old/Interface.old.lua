local Interface = HideUI:NewModule("Interface")

function Interface:OnInitialize()
end

function Interface:OnEnable()
    self:CreateMainWindow()
end

---------------------------------------------------------------------
-- Main Frame
---------------------------------------------------------------------
-- Crea la ventana principal contenedora
function Interface:CreateMainWindow()
    local frame = HideUIWindow

    -- Poder mover la ventana
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)

    -- Color de fondo y borde
    frame:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        edgeSize = 12,
        insets = { left = 2, right = 2, top = 2, bottom = 2 }
    })
    frame:SetBackdropColor(0, 0, 0, 0.85)
    frame:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
    
    self:CreateMenuButton(
        frame.CloseButton, "Close", {0, 0, 0, 0}, function() frame:Hide() end
    )
    self:CreateMenuButton(
        frame.MainButton, "Main", {0, 0, 0, 0.35}, function() end
    )
    self:CreateMenuButton(
        frame.FrameButton, "Frames", {0, 0, 0, 0.35}, function() end
    )
    self:CreateMenuButton(
        frame.OtherButton, "Others", {0, 0, 0, 0.35}, function() end
    )
end

function Interface:CreateMenuButton(button, text, backdropColor, onClick)
    -- Color del button
    button:SetBackdrop({bgFile = "Interface/Tooltips/UI-Tooltip-Background",})
    button:SetBackdropColor( unpack(backdropColor) ) -- Colorear para debug

    -- Texto del button y el action
    button.Text:SetText(text)

    button:SetScript("OnClick", function()
        onClick()
    end)
    button:SetScript("OnEnter", function()
        button.Text:SetTextColor(1, 0.82, 0)
    end)
    button:SetScript("OnLeave", function()
        button.Text:SetTextColor(1, 1, 1)
    end)
end