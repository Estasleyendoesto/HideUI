-- ui_schema_other.lua
HideUI.UISchemaOther = {
    {
        name = "Enable Frame",
        type = "checkbox",
        var  = "enable_checkbox",
        tooltip = "Enable customization for the selected frame.",
    },
    {
        name = "Enable Mouseover",
        type = "checkbox",
        var  = "mouseover_checkbox",
        tooltip = "Enable mouseover reveal for the selected frame."
    },
    {
        name = "Opacity",
        type = "slider",
        var  = "opacity_slider",
        tooltip = "Adjust the opacity of the selected frame."
    },
    {
        name = "AFK Opacity",
        type = "checkbox_slider",
        var  = "afk_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is away from keyboard."
    },
    {
        name = "Mounted Opacity",
        type = "checkbox_slider",
        var  = "mount_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is on a mount."
    },
    {
        name = "In-Combat Opacity",
        type = "checkbox_slider",
        var  = "combat_checkbox_slider",
        tooltip = "Customizes frame opacity when entering combat."
    },
    {
        name = "In-Instance Opacity",
        type = "checkbox_slider",
        var  = "instance_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is inside an instance."
    },
}