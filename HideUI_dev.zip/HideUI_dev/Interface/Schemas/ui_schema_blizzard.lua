-- ui_schema_blizzard.lua
HideUI.UISchemaBlizzard = {
    {
        name = "Enable Frame",
        type = "checkbox",
        var  = "enable_checkbox",
        tooltip = "Enable customization for the selected frame.",
    },
    {
        name = "Enable Mouseover",
        type = "checkbox",
        var  = "mouseover_checkbox",
        tooltip = "Enable mouseover reveal for the selected frame."
    },
    {
        name = "Opacity",
        type = "slider",
        var  = "opacity_slider",
        tooltip = "Adjust the opacity of the selected frame."
    },
    {
        name = "AFK Opacity",
        type = "checkbox_slider",
        var  = "afk_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is away from keyboard."
    },
    {
        name = "Mounted Opacity",
        type = "checkbox_slider",
        var  = "mount_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is on a mount."
    },
    {
        name = "In-Combat Opacity",
        type = "checkbox_slider",
        var  = "combat_checkbox_slider",
        tooltip = "Customizes frame opacity when entering combat."
    },
    {
        name = "In-Instance Opacity",
        type = "checkbox_slider",
        var  = "instance_checkbox_slider",
        tooltip = "Adjusts frame opacity when the player is inside an instance."
    },
    -- -----------------------------------------------------------------
    -- INDIVIDUAL FRAMES
    -- -----------------------------------------------------------------
    {
        name = "Enable Text Mode (Experimental)",
        type = "checkbox",
        var  = "text_checkbox",
        tooltip = "Hide the chat box, leaving only the messages visible.",
        frame  = "Chatbox" -- opcional, si solo aplica a ese frame
    }
}

HideUI.UIFrameOrderBlizzard = {
    -- Chatbox
    "Chatbox",
    -- Frames
    "PlayerFrame",
    "TargetFrame",
    "FocusFrame",
    "PetFrame",
    -- Misc
    "MinimapCluster",
    "BuffFrame",
    "MicroMenuContainer",
    "BagsBar",
    "BattlefieldMapFrame",
    "EncounterBar",
    "PlayerCastingBarFrame",
    "MainStatusTrackingBarContainer",
    "SecondaryStatusTrackingBarContainer",
    "StanceBar",
    "PartyFrame",
    -- Spell Bars
    "MainMenuBar",
    "MultiBarBottomLeft",
    "MultiBarBottomRight",
    "MultiBarRight",
    "MultiBarLeft",
    "MultiBar5",
    "MultiBar6",
    "MultiBar7",
    "PetActionBar",
    "ZoneAbilityFrame",
}