-- ui_mappings.lua
HideUI.UIMappings = {
  character_checkbox   = "isCharacter",
  enable_checkbox      = "isEnabled",
  mouseover_checkbox   = "isMouseoverEnabled",
  fadeIn_slider        = "mouseoverFadeInDuration",
  fadeOut_slider       = "mouseoverFadeOutDuration",
  opacity_slider       = "alphaAmount",
  afk_checkbox         = "isAFKEnabled",
  afk_slider           = "afkAlphaAmount",
  mount_checkbox       = "isMountEnabled",
  mount_slider         = "mountAlphaAmount",
  combat_checkbox      = "isCombatEnabled",
  combat_slider        = "combatAlphaAmount",
  instance_checkbox    = "isInstanceEnabled",
  instance_slider      = "instanceAlphaAmount",
  postcombat_slider    = "combatEndDelay",
  -- Extras
  text_checkbox       = "isTextModeEnabled",
}