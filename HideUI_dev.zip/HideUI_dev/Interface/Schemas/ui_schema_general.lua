-- ui_schema_general.lua
HideUI.UISchemaGeneral = {
    {
        name="Character-specific",
        type="checkbox",
        var="character_checkbox",
        tooltip="Enable to apply changes to character-specific settings. Disable to revert to shared settings."
    },
    {
        name="Enable HideUI",
        type="checkbox",
        var="enable_checkbox",
        tooltip="Toggle the addon's full functionality. Ideal for resetting in case of erratic behavior or as a replacement for Ctrl + Z. You can bind a key in Keybinds -> HideUI." 
    },
    {
        name="Enable Mouseover",   
        type="checkbox",        
        var="mouseover_checkbox",
        tooltip="Toggle frame visibility on mouseover for all frames." 
    },
    {
        name="Fade In Duration",
        type="slider",
        var="fadeIn_slider",
        max=2,
        unit="s"
    },
    {
        name="Fade Out Duration",
        type="slider",
        var="fadeOut_slider",
        max=2,
        unit="s"
    },
    {
        name="Global Opacity",
        type="slider",
        var="opacity_slider",
        tooltip="Adjusts the overall opacity for all frames."
    },
    {
        name="AFK Opacity",
        type="checkbox_slider",
        var="afk_checkbox_slider",
        tooltip="Adjusts the global opacity when the player is away from the keyboard."
    },
    {
        name="Mounted Opacity",
        type="checkbox_slider",
        var="mount_checkbox_slider",
        tooltip="Adjusts the global opacity when the player is mounted."
    },
    {
        name="In-Combat Opacity",
        type="checkbox_slider",
        var="combat_checkbox_slider",
        tooltip="Adjusts global opacity upon entering combat."
    },
    {
        name="In-Instance Opacity",
        type="checkbox_slider",
        var="instance_checkbox_slider",
        tooltip="Adjusts global opacity while the player is inside an instance."
    },
    {
        name="Post-Combat Fade Delay",
        type="slider",
        var="postcombat_slider",
        max=2,
        unit="s",
        tooltip="Delay before the interface begins changing opacity after combat ends."
    },
}