local General = HideUI:NewModule("General")
local Dispatcher
local UIManager
local Interface
local Data -- (read-only)

local MENU_NAME = "General"
local MAPPINGS  = HideUI.UIMappings
local SCHEMA    = HideUI.UISchemaGeneral

function General:OnInitialize()
    Dispatcher = HideUI:GetModule("Dispatcher")
    Interface  = HideUI:GetModule("Interface")
    UIManager  = HideUI:GetModule("UIManager")
    Data       = HideUI:GetModule("Data")
end

--==============================================================
-- Enable/Disable módulo
--==============================================================
function General:OnEnable()
    self.registry = {}
    self:Draw()
end

function General:OnDisable()
    self.registry = nil
end

--==============================================================
-- Refrescar datos de la UI
--==============================================================
function General:UpdateUI()
    for uivar, map in pairs(MAPPINGS) do
        Interface:SetVariableData(self.registry, uivar, Data.Globals[map])
    end
end

--==============================================================
-- Reacción tras interacción del usuario.
-- Enciende/apaga el addon, cambio de perfil, y ajuste de globals
--==============================================================
function General:OnUpdate(variable, data)
    local map = MAPPINGS[variable]
    local is_enable = variable == "enable_checkbox" -- Addon toggle
    local is_character = variable == "character_checkbox" -- Chara profile

    if is_enable then
        Dispatcher:HandleEnabledChange(data)
    elseif is_character then
        Interface:CreatePopupDialog(function(confirm)
            if confirm then
                Dispatcher:HandleProfileChange(data)
            else
                Interface:SetVariableData(General.registry, "character_checkbox", not data)
            end
        end)
    else
        Dispatcher:SetGlobalSettings(map, data)
    end
end

--==============================================================
-- Botón de reiniciar variables a default
--==============================================================
function General:OnDefault()
    Interface:CreatePopupDialog(function(confirm)
        if confirm then
            Dispatcher:RestoreGlobals()
        end
    end)
end

--==============================================================
-- Encendido/Apagado de la interfaz
--==============================================================
function General:SetEnable(enable)
    if enable then self.categoryHeader:SetEnable() else self.categoryHeader:SetDisable() end
    local section = self.scrollContainer:GetChildren()
    local children = {section.Container:GetChildren()}
    local frame = Interface:GetElementByVariable("enable_checkbox")
    for _, child_element in ipairs(children) do
        if child_element ~= frame then
            if enable then child_element:SetEnable() else child_element:SetDisable() end
        end
    end
end

function General:TurnOn()
   self:SetEnable(true)
end

function General:TurnOff()
    self:SetEnable(false)
end

--==============================================================
-- Dibujado de elementos individuales
--==============================================================
function General:Draw()
    self.subcategory, self.layout, self.frame = Interface:CreateLayoutSubcategory(UIManager.category, MENU_NAME)
    self.categoryHeader = Interface:CreateCategoryHeader(MENU_NAME, self.frame, self.OnDefault)
    self.scrollContainer = Interface:CreateScrollContainer(self.frame, {y = -50}, true, 560)

    local section = Interface:CreateSection(nil, "empty", self.scrollContainer, nil, {y = -6})

    local prev
    local defaults = { data = self.registry, update = function(var, val) self:OnUpdate(var, val) end }

    local function add(desc)
        local settings = Interface:RegisterSettings({
            name     = desc.name,
            type     = desc.type,
            variable = desc.var,
            tooltip  = desc.tooltip,
            unit     = desc.unit,
            max      = desc.max,
        }, defaults)
        prev = Interface:AddElementToSection(section, settings, prev)
    end

    for _, desc in ipairs(SCHEMA) do add(desc) end
end