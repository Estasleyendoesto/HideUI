local Other = HideUI:NewModule("Other")
local Dispatcher
local Interface
local UIManager
local Data -- (read-only)

local MENU_NAME = "Other"
local HEADER = "Third-Party Frames"
local MAPPINGS  = HideUI.UIMappings
local SCHEMA    = HideUI.UISchemaOther

function Other:OnInitialize()
    Dispatcher = HideUI:GetModule("Dispatcher")
    Interface  = HideUI:GetModule("Interface")
    Data       = HideUI:GetModule("Data")
    UIManager  = HideUI:GetModule("UIManager")
end

--==============================================================
-- Enable/Disable módulo
--==============================================================
function Other:OnEnable()
    self.registry = {}
    self.frames = {}
    self:LoadFrames()
    self:Draw()
end

function Other:OnDisable()
    self:Purge()
    self.registry = nil
    self.frames = nil
    self.before = nil
end

--==============================================================
-- Refrescar datos de la UI
--==============================================================
function Other:UpdateUI()
    local field
    local frame
    local setup
    for variable, _ in pairs(self.registry) do
        frame, setup = strsplit(".", variable)
        field = MAPPINGS[setup]
        Interface:SetVariableData(self.registry, variable, Data.Frames[frame][field])
    end
    -- Segundo recorrido necesario para actualizar verdaderamente los checkbox_slider
    for variable, _ in pairs(self.registry) do
        frame, setup = strsplit(".", variable)
        field = MAPPINGS[setup]
        if field == "isEnabled" then
            Interface:SetExpandableState(self.registry, variable, Data.Frames[frame][field])
        end
    end
end

--==============================================================
-- Reacción tras interacción del usuario.
-- Ajuste de los campos de los frames y/o expandido de ventana
--==============================================================
function Other:OnUpdate(variable, data)
    local frame, setup = strsplit(".", variable)
    local field = MAPPINGS[setup]
    Dispatcher:SetFrameSettings(frame, field, data)

    if field == "isEnabled" then
        Interface:SetExpandableState(Other.registry, variable, data)
    end
end

--==============================================================
-- Botón de reiniciar variables a default
--==============================================================
function Other:OnDefault()
    Interface:CreatePopupDialog(function(confirm)
        if confirm then
            Dispatcher:RestoreOtherFrames()
        end
    end)
end

--==============================================================
-- Encendido/Apagado de la interfaz
--==============================================================
function Other:SetEnable(enable)
    if enable then self.categoryHeader:SetEnable() else self.categoryHeader:SetDisable() end
    local sections = {self.scrollContainer:GetChildren()}
    for _, child_section in ipairs(sections) do
        if enable then child_section:SetEnable() else child_section:SetDisable() end
    end
end

function Other:TurnOn()
    self:SetEnable(true)
end

function Other:TurnOff()
    self:SetEnable(false)
end

--==============================================================
-- Carga todos los frames de la BD marcados como "community"
--==============================================================
function Other:LoadFrames()
    self.frames = {}
    for _, frame in pairs(Data.Frames) do
        if frame.source == "community" then
            table.insert(self.frames, {name = frame.name, alias = frame.alias or frame.name})
        end
    end
end

--==============================================================
-- Elimina totalmente la interfaz, dejando un panel vacío 
--==============================================================
function Other:Purge()
    local sections = {self.scrollContainer:GetChildren()}
    for _, child_section in ipairs(sections) do
        Interface:ClearSection(child_section)
        child_section:Hide()
        child_section:SetParent(nil)
        child_section = nil
    end
    self.searchbox:SetParent(nil)
    self.scrollContainer:Hide()
    self.categoryHeader:Hide()
    self.searchbox = nil
    self.scrollContainer = nil
    self.categoryHeader = nil
end

--==============================================================
-- Destruye y rehace la interfaz
--==============================================================
function Other:Rebuild()
    self:Purge()
    self.registry = {}
    self.frames = nil
    self.before = nil

    self:LoadFrames()
    self:Redraw()
end

--==============================================================
-- Rellena la interfaz con los frames registrados
--==============================================================
function Other:Refresh()
    self.registry = {}
    self:LoadFrames()
    local index
    local sections = {self.scrollContainer:GetChildren()}
    for _, child_section in ipairs(sections) do
        index = Interface:GetIndex(child_section)
        if index > 1 then
            Interface:ClearSection(child_section)
            child_section:Hide()
            child_section:SetParent(nil)
            child_section = nil
        end
    end
    self:InsertSections()
    self:UpdateUI()
end

--==============================================================
-- Añade y elimina un frame del registro
-- Recibe mensaje de botones de añadir/eliminar. 
--==============================================================
function Other:OnCommand(command, input, control)
    if command == "add" then
        local result = Dispatcher:RegisterFrame(input)
        if result then
            Other:Refresh()
            control.SetTextSuccessful("Frame successfully registered.")
        else
            control.SetTextError("Frame not found or already registered.")
        end
    elseif command == "remove" then
        local result = Dispatcher:UnregisterFrame(input)
        if result then
            Other:Refresh()
            control.SetTextSuccessful("Frame successfully unregistered.")
        else
            control.SetTextError("Frame not found.")
        end
    end
end

--==============================================================
-- Dibujado de la interfaz
--==============================================================
function Other:Draw()
    self.subcategory, self.layout, self.frame = Interface:CreateLayoutSubcategory(UIManager.category, MENU_NAME)
    self:InitializeUI()
end

-- Redibujado
function Other:Redraw()
    self:InitializeUI()
end

-- Registro categoría y creación del scroll
function Other:InitializeUI()
    self.categoryHeader = Interface:CreateCategoryHeader(HEADER, self.frame, self.OnDefault)
    self.scrollContainer = Interface:CreateScrollContainer(self.frame, {y = -50})

    -- Registro del cuadro de búsqueda
    local tooltip = {
        name = "Search",
        text = "Search for a frame by its name; you can find it by typing /fstack in the chat."
    }
    self.searchbox = Interface:CreateSearchBox(self.scrollContainer, nil, self.OnCommand, tooltip)
    self:InsertSections()
end

function Other:InsertSections()
    self.before = nil
    for k, frame in ipairs(self.frames) do
        self:BuildSection(frame.name, frame.alias)
    end

    Interface:CreateSection(nil, "empty", self.scrollContainer, self.before, {h = 50})
end

function Other:BuildSection(frame, header)
    local offset
    local settings
    local prev

    if self.before then
        offset = -9
    else
        self.before = self.searchbox
        offset = -20
    end

    local defaults = {data = self.registry, update = self.OnUpdate}
    local section = Interface:CreateSection(header, "expandable", self.scrollContainer, self.before, {y = offset})

    for i, desc in ipairs(SCHEMA) do
        if not (desc.frame and desc.frame ~= frame) then
            local variable = frame .. "." .. (desc.var or "")

            settings = Interface:RegisterSettings({
                name     = desc.name,
                type     = desc.type,
                variable = variable,
                tooltip  = desc.tooltip,
            }, defaults)

            prev = Interface:AddElementToSection(section, settings, prev, (i == 1) and { y = -13 } or nil)
        end
    end

    settings  = Interface:RegisterSettings({type="separator"})
    prev      = Interface:AddElementToSection(section, settings, prev, {y = -20})

    self.before = section
end