local Interface = HideUI:NewModule("Interface")

--==============================================================
-- Inicialización
--==============================================================
function Interface:OnInitialize() end
function Interface:OnEnable() end

--==============================================================
-- Utils
--==============================================================
-- Transform genérico
function Interface:CreateTransform(args)
    args = args or {}
    return {
        x = args.x or 0,
        y = args.y or 0,
        w = args.w or 1,
        h = args.h or 1,
    }
end

-- Siguiente índice para hijos (evita recorrer todo cada vez)
local function NextChildIndex(parent)
    parent.__hideui_last_index = (parent.__hideui_last_index or 0) + 1
    return parent.__hideui_last_index
end

function Interface:SetIndex(frame)
    local parent = frame:GetParent()
    frame.index = NextChildIndex(parent)
    return frame.index
end

function Interface:GetIndex(frame)
    return (frame and frame.index) or 0
end

-- Obtiene último hijo por .index si lo necesitas en algún flujo
function Interface:GetLastElement(container)
    local last, lastChild = 0, nil
    for _, child in ipairs({container:GetChildren()}) do
        child.index = child.index or 0
        if child.index > last then
            last = child.index
            lastChild = child
        end
    end
    if lastChild then return last, lastChild end
    return 0
end

-- Tamaño ancho: opcionalmente setea
function Interface:CalculateWidth(frame, noSet)
    local width = frame:GetParent():GetWidth()
    if not noSet then
        frame:SetWidth(width)
        if frame.Container then frame.Container:SetWidth(width) end
    end
    return width
end

-- Alto total de la sección y de su container
function Interface:CalculateHeight(frame, noSet)
    local height, extra = 0, 0

    if frame.Header then
        local _, _, _, _, oy = frame.Header:GetPoint()
        extra = extra + math.abs(oy) + frame.Header:GetHeight()
    end
    if frame.Button then
        local _, _, _, _, oy = frame.Button:GetPoint()
        extra = extra + math.abs(oy) + frame.Button:GetHeight()
    end
    if frame.Container then
        for _, child in ipairs({frame.Container:GetChildren()}) do
            local _, _, _, _, oy = child:GetPoint()
            height = height + math.abs(oy) + child:GetHeight()
        end
    end

    local total = height + extra
    if not noSet then
        frame:SetHeight(total)
        if frame.Container then frame.Container:SetHeight(height) end
    end
    return total, height, extra
end

-- Hermano siguiente por índice
function Interface:GetNextChild(frame)
    local parent = frame:GetParent()
    local idx = self:GetIndex(frame)
    for _, child in ipairs({parent:GetChildren()}) do
        if self:GetIndex(child) == idx + 1 then
            return child
        end
    end
    return nil --No hay siguiente...
end

-- Anclar
function Interface:FixTo(frame, relativeTo, transform)
    frame:ClearAllPoints()
    transform = self:CreateTransform(transform)
    if relativeTo then
        frame:SetPoint("TOPLEFT", relativeTo, "BOTTOMLEFT", transform.x, transform.y)
    else
        frame:SetPoint("TOPLEFT", transform.x, transform.y)
    end
end

-- Debug fondo
function Interface:Debug(frame, channel)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints(true)
    bg:SetColorTexture(channel.r or 0, channel.g or 0, channel.b or 0, 0.25)
    frame.bg = bg
end

-- unpack compat
function Interface:Unpack(tbl)
    local _unpack = table.unpack or unpack
    return _unpack(tbl)
end

-- Registro de variables
function Interface:RegisterVariable(tbl, variable_name, element)
    if tbl and variable_name and element then
        tbl[variable_name] = element
    end
end

-- Setter de datos de variable (corregida nomenclatura Sliderbox/SiderFrame inconsistente)
function Interface:SetVariableData(tbl, variable_name, data)
    local frame = tbl[variable_name]
    if not frame or not frame.GetName then return end

    local name = frame:GetName()
    if name == "HideUICheckboxSlider" then
        if type(data) == "number" then
            frame.Sliderbox.Slider:SetValue(data)
        elseif type(data) == "boolean" then
            frame.Checkbox:SetChecked(data)
            if data then frame.Sliderbox:SetEnable() else frame.Sliderbox:SetDisable() end
        end
    elseif name == "HideUICheckbox" then
        frame.Checkbox:SetChecked(data)
    elseif name == "HideUISlider" then
        frame.Sliderbox.Slider:SetValue(data)
    end
end

-- Getter de datos (unificado a .Sliderbox)
function Interface:GetVariableData(tbl, var_name)
    local frame = tbl[var_name]
    if not frame or not frame.GetName then return nil end

    local name = frame:GetName()
    if name == "HideUICheckbox" then
        return frame.Checkbox:GetChecked()
    elseif name == "HideUISlider" then
        return frame.Sliderbox.Slider:GetValue()
    elseif name == "HideUICheckboxSlider" then
        return frame.Checkbox:GetChecked(), frame.Sliderbox.Slider:GetValue()
    end
    return nil
end

function Interface:GetElementByVariable(tbl, variable)
    return tbl[variable]
end

--==============================================================
-- Subcategory
--==============================================================
function Interface:CreateLayoutSubcategory(category, name)
    local frame = CreateFrame("Frame", "HideUI" .. name .. "Frame", UIParent)
    local subcategory, layout = Settings.RegisterCanvasLayoutSubcategory(category, frame, name)
    frame.name = name
    return subcategory, layout, frame
end

--==============================================================
-- Scroll
--==============================================================
function Interface:CreateScrollContainer(parent, transform, fill, desiredWidth)
    local scrollFrame = CreateFrame("ScrollFrame", "HideUIScroll", parent, "HideUIScrollFrameTemplate")

    transform = self:CreateTransform(transform)
    scrollFrame:SetPoint("TOPLEFT", transform.x, transform.y)

    if fill ~= false then
        scrollFrame:SetPoint("BOTTOMRIGHT")
    end

    local scrollChild = scrollFrame:GetScrollChild()
    local width = desiredWidth or (UIParent:GetWidth() * 0.344) -- configurable
    scrollChild:SetSize(width, 1)
    scrollChild:SetPoint("TOPLEFT")
    scrollChild:SetPoint("BOTTOMRIGHT")

    return scrollChild, scrollFrame
end

--==============================================================
-- Header
--==============================================================
function Interface:CreateCategoryHeader(name, parent, func)
    local headerFrame = CreateFrame("Frame", "HideUIHeader", parent, "HideUIHeaderTemplate")
    headerFrame:SetHeight(50)
    headerFrame:SetPoint("TOPLEFT")
    headerFrame:SetPoint("TOPRIGHT")

    headerFrame.Header.Title:SetText(name)
    headerFrame.Header.DefaultsButton:SetText("Defaults")
    headerFrame.Header.DefaultsButton:SetScript("OnClick", func)

    function headerFrame.SetEnable() headerFrame.Header.DefaultsButton:Enable() end
    function headerFrame.SetDisable() headerFrame.Header.DefaultsButton:Disable() end

    return headerFrame
end

--==============================================================
-- Sections
--==============================================================
function Interface:CreateSection(name, type, parent, relativeTo, transform)
    if type == "empty" then
        return self:CreateEmptySection(parent, relativeTo, transform)
    elseif type == "header" then
        return self:CreateHeaderSection(name, parent, relativeTo, transform)
    elseif type == "expandable" then
        return self:CreateExpandableSection(name, parent, relativeTo, transform)
    end
end

function Interface:CreateEmptySection(parent, relativeTo, transform)
    local section = CreateFrame("Frame", "HideUIEmptySection", parent, "HideUIEmptySectionTemplate")
    self:CalculateWidth(section)
    self:CalculateHeight(section)
    self:SetIndex(section)
    self:FixTo(section, relativeTo, transform)

    if transform and transform.h then section:SetHeight(transform.h) end

    section.SetEnable = function() end
    section.SetDisable = function() end
    return section
end

function Interface:CreateHeaderSection(name, parent, relativeTo, transform)
    local section = CreateFrame("Frame", "HideUISection", parent, "HideUISectionTemplate")
    self:CalculateWidth(section)
    self:CalculateHeight(section)
    self:SetIndex(section)
    self:FixTo(section, relativeTo, transform)

    section.SetEnable = function() end
    section.SetDisable = function() end

    section.Header.Title:SetText(name)
    return section
end

function Interface:CreateExpandableSection(name, parent, relativeTo, transform)
    local section = CreateFrame("Frame", "HideUIExpandableSection", parent, "HideUIExpandableSectionTemplate")
    self:CalculateWidth(section)
    self:CalculateHeight(section)
    self:SetIndex(section)
    self:FixTo(section, relativeTo, transform)

    -- Visibility
    function section.HideContainer()
        local height = section:GetHeight() - section.Container:GetHeight()
        section:SetHeight(height)
        section.Container:SetHeight(0)
        section.Container:Hide()
    end
    function section.ShowContainer()
        Interface:CalculateHeight(section)
        section.Container:Show()
    end

    -- Toggle
    function section.SetEnable() section.Button:Enable() end
    function section.SetDisable()
        section.Button:Disable()
        Interface:OnExpandedChange(section, false)
    end

    section.Button.Text:SetText(name)
    function section.Shutdown()
        section.Button.Text:SetTextColor(1, 1, 1, 0.7)
        section:SetAlpha(0.8)
    end
    function section.SwitchOn()
        section.Button.Text:SetTextColor(1, 0.84, 0, 1)
        section:SetAlpha(1)
    end

    section.Button.expanded = false
    section.Button:SetScript("OnClick", function(button)
        button.expanded = not button.expanded
        Interface:OnExpandedChange(section, button.expanded)
    end)

    return section
end

function Interface:OnExpandedChange(section, expanded)
    local button = section.Button
    if expanded then
        section:ShowContainer()
        button.Right:SetAtlas("Options_ListExpand_Right_Expanded", TextureKitConstants.UseAtlasSize)
    else
        section:HideContainer()
        button.Right:SetAtlas("Options_ListExpand_Right", TextureKitConstants.UseAtlasSize)
    end
end

function Interface:SetExpandableState(registry, variable, enabled)
    local element   = self:GetElementByVariable(registry, variable)
    local container = element:GetParent()
    local section   = container:GetParent()

    if enabled then section:SwitchOn() else section:Shutdown() end

    for _, child in ipairs({container:GetChildren()}) do
        if child ~= element then
            if enabled then child:SetEnable() else child:SetDisable() end
        end
    end
end

function Interface:ClearSection(section)
    for _, child in ipairs({section:GetChildren()}) do
        child:Hide()
        child:SetParent(nil)
    end
end

--==============================================================
-- Quick Elements
--==============================================================
function Interface:RegisterSettings(args, defaults)
    local settings = {}
    for k, v in pairs(defaults or {}) do settings[k] = v end
    for k, v in pairs(args or {}) do settings[k] = v end
    return settings
end

function Interface:AddElementToSection(section, settings, relativeTo, transform)
    local container = section.Container
    local slider_settings = {
        default = settings.slider_default,
        step    = settings.step,
        min     = settings.min,
        max     = settings.max,
        unit    = settings.unit
    }

    local checkbox_slider
    if settings.type == "checkbox_slider" then
        local base = settings.variable and settings.variable:match("^(.+)_checkbox_slider$")
        if base then checkbox_slider = { base .. "_checkbox", base .. "_slider" } end
    end

    local function update(element, data)
        if checkbox_slider then
            local select = (type(data) == "boolean") and checkbox_slider[1] or checkbox_slider[2]
            Interface:SetVariableData(settings.data, select, data)
            settings.update(nil, select, data)
        else
            Interface:SetVariableData(settings.data, settings.variable, data)
            settings.update(nil, settings.variable, data)
        end
    end

    -- Offset pequeño
    transform = transform or {}
    transform = { y = (transform.y or 0) - 5 }

    local element
    if settings.type == "checkbox" then
        element = self:CreateCheckbox(settings.name, container, relativeTo, transform, update, settings.tooltip, settings.default)
    elseif settings.type == "slider" then
        element = self:CreateSlider(settings.name, container, relativeTo, transform, update, settings.tooltip, slider_settings)
    elseif settings.type == "checkbox_slider" then
        element = self:CreateCheckboxSlider(settings.name, container, relativeTo, transform, update, settings.tooltip, settings.default, slider_settings)
    elseif settings.type == "separator" then
        element = self:CreateSeparator(container, relativeTo, transform)
    end

    self:CalculateHeight(section)

    if checkbox_slider then
        self:RegisterVariable(settings.data, checkbox_slider[1], element)
        self:RegisterVariable(settings.data, checkbox_slider[2], element)
    else
        self:RegisterVariable(settings.data, settings.variable, element)
    end

    if section:GetName() == "HideUIExpandableSection" then
        -- ‘expanded’ estaba indefinida antes; usamos el estado real del botón o false
        self:OnExpandedChange(section, section.Button and section.Button.expanded or false)
    end

    return element
end

--==============================================================
-- Tooltip
--==============================================================
function Interface:CreateTooltip(frame, name, text)
    frame:SetScript("OnEnter", function()
        GameTooltip:SetOwner(frame, "ANCHOR_RIGHT")
        GameTooltip:SetText(name, 1, 1, 1)
        if text then GameTooltip:AddLine(text, 1, 0.84, 0, true) end
        GameTooltip:Show()
    end)
    frame:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

--==============================================================
-- Checkbox
--==============================================================
local function SetControlEnable(control, alpha)
    control:SetAlpha(alpha or 1)
end

function Interface:CreateCheckbox(name, parent, relativeTo, transform, update, tooltip, default, frame_name)
    default     = default or false
    update      = update  or function() end
    frame_name  = frame_name or "HideUICheckbox"

    local control = CreateFrame("Frame", frame_name, parent, "HideUICheckboxControlTemplate")
    self:SetIndex(control)
    self:FixTo(control, relativeTo, transform)

    control.Text:SetText(name)
    control.Text:SetPoint("LEFT", control, "LEFT", 45, 0)
    control.Text:SetWidth(180)
    control.Text:SetMaxLines(1)
    control.Text:SetNonSpaceWrap(false)

    local checkbox = CreateFrame("CheckButton", nil, control, "HideUICheckboxTemplate")
    checkbox:SetPoint("LEFT", parent, "CENTER", -85, 0)
    checkbox:SetPoint("TOP", control, "TOP", 0, 0)
    checkbox:SetChecked(default)
    checkbox:SetScript("OnClick", function() update(checkbox, checkbox:GetChecked()) end)

    function control.SetEnable()
        SetControlEnable(control, 1)
        control.Checkbox:SetAlpha(1); control.Checkbox:Enable()
    end
    function control.SetDisable()
        SetControlEnable(control, 0.4)
        control.Checkbox:SetAlpha(0.4); control.Checkbox:Disable()
    end

    self:CreateTooltip(control.Text, name, tooltip)
    control.Checkbox = checkbox
    return control
end

--==============================================================
-- Slider
--==============================================================
function Interface:SliderSettingsInitializer(args)
    args = args or {}
    local default = args.default or 1
    local step    = args.step or 0.01
    local min     = args.min or 0
    local max     = args.max or 1
    local unit    = args.unit or "%"

    return { default, step, min, max, unit }
end

function Interface:CreateSliderbox(control, update, default, step, min, max, unit)
    local parent = control:GetParent()
    local sliderbox = CreateFrame("Frame", nil, control, "HideUISliderTemplate")
    sliderbox:SetPoint("LEFT", parent, "CENTER", -85, 0)
    sliderbox:SetPoint("TOP", control, "TOP", 0, 0)

    function sliderbox.DefineText(text, value)
        if text == "%" then
            value = value * 100
            text  = string.format("%.0f", value) .. text
        else
            text  = string.format("%.1f", value) .. text
        end
        sliderbox.RightText:SetText(text)
        return text
    end

    if sliderbox.RightText then
        sliderbox.DefineText(unit, default)
        sliderbox.RightText:Show()
    end

    local slider = sliderbox.Slider
    if slider then
        slider:SetMinMaxValues(min, max)
        slider:SetValue(default)
        slider:SetValueStep(step)
        slider:SetScript("OnValueChanged", function(_, value)
            sliderbox.DefineText(unit, value)
            value = tonumber(string.format("%.2f", value))
            update(slider, value)
        end)
    end

    local backButton = sliderbox.Back
    if backButton then
        backButton:SetScript("OnClick", function()
            slider:SetValue(slider:GetValue() - step)
            sliderbox.DefineText(unit, slider:GetValue())
        end)
    end

    local forwardButton = sliderbox.Forward
    if forwardButton then
        forwardButton:SetScript("OnClick", function()
            slider:SetValue(slider:GetValue() + step)
            sliderbox.DefineText(unit, slider:GetValue())
        end)
    end

    function sliderbox.SetEnable()
        sliderbox:SetAlpha(1)
        sliderbox.Slider:Enable()
        sliderbox.Back:Enable()
        sliderbox.Forward:Enable()
    end
    function sliderbox.SetDisable()
        sliderbox:SetAlpha(0.4)
        sliderbox.Slider:Disable()
        sliderbox.Back:Disable()
        sliderbox.Forward:Disable()
    end

    return sliderbox
end

function Interface:CreateSlider(name, parent, relativeTo, transform, update, tooltip, slider_settings)
    update = update or function() end
    slider_settings = self:SliderSettingsInitializer(slider_settings)

    local control = CreateFrame("Frame", "HideUISlider", parent, "HideUISliderControlTemplate")
    self:SetIndex(control)
    self:FixTo(control, relativeTo, transform)

    control.Text:SetText(name)
    control.Text:SetPoint("LEFT", control, "LEFT", 45, 0)
    control.Text:SetWidth(201)
    control.Text:SetMaxLines(1)
    control.Text:SetNonSpaceWrap(false)

    local sliderbox = self:CreateSliderbox(control, update, self:Unpack(slider_settings))

    function control.SetEnable()
        control:SetAlpha(1)
        control.Sliderbox.SetEnable()
    end
    function control.SetDisable()
        control:SetAlpha(0.4)
        control.Sliderbox.SetDisable()
    end

    self:CreateTooltip(control.Text, name, tooltip)
    control.Sliderbox = sliderbox
    return control
end

--==============================================================
-- Checkbox + Slider
--==============================================================
function Interface:CreateCheckboxSlider(name, parent, relativeTo, transform, update, tooltip, checkbox_default, slider_settings)
    local frame_name = "HideUICheckboxSlider"
    update = update or function() end
    slider_settings = self:SliderSettingsInitializer(slider_settings)

    local function checkbox_update(checkbox, checked)
        local sliderbox = checkbox:GetParent().Sliderbox
        if checked then sliderbox:SetEnable() else sliderbox:SetDisable() end
        update(checkbox, checked)
    end

    local control = self:CreateCheckbox(name, parent, relativeTo, transform, checkbox_update, tooltip, checkbox_default, frame_name)
    control:SetWidth(545)

    local sliderbox = self:CreateSliderbox(control, update, self:Unpack(slider_settings))
    sliderbox:ClearAllPoints()
    sliderbox:SetPoint("LEFT", parent, "CENTER", -50, 0)
    sliderbox:SetPoint("TOP", control, "TOP", 0, 0)
    sliderbox:SetWidth(215)

    local originalEnable  = control.SetEnable
    local originalDisable = control.SetDisable

    function control.SetEnable()
        originalEnable()
        if control.Checkbox:GetChecked() then control.Sliderbox:SetEnable() end
    end
    function control.SetDisable()
        originalDisable()
        if control.Checkbox:GetChecked() then control.Sliderbox:SetDisable() end
    end

    if checkbox_default then sliderbox:SetEnable() else sliderbox:SetDisable() end

    control.Sliderbox = sliderbox
    return control
end

--==============================================================
-- Popup Dialog
--==============================================================
function Interface:CreatePopupDialog(func)
    func = func or function() end
    StaticPopupDialogs["HIDEUI_CONFIRM_DIALOG"] = {
        text = "Are you sure you want to proceed?",
        button1 = "Yes",
        button2 = "No",
        OnAccept = function() func(true) end,
        OnCancel = function() func(false) end,
        timeout = 0,
        whileDead = false,
        hideOnEscape = true,
    }
    StaticPopup_Show("HIDEUI_CONFIRM_DIALOG")
end

--==============================================================
-- Separator
--==============================================================
function Interface:CreateSeparator(parent, relativeTo, transform)
    local separator = CreateFrame("Frame", "HideUISeparator", parent)
    separator:SetHeight(1)
    self:CalculateWidth(separator, true)
    self:SetIndex(separator)
    self:FixTo(separator, relativeTo, transform)

    separator.SetEnable = function() end
    separator.SetDisable = function() end
    return separator
end

--==============================================================
-- SearchBox
--==============================================================
function Interface:CreateSearchBox(parent, transform, func, tooltip)
    local control = CreateFrame("Frame", "HideUISearchBox", parent, "HideUISearchBoxTemplate")
    self:SetIndex(control)
    self:FixTo(control, nil, transform)
    self:CalculateWidth(control)

    local rightTextDelay = 3
    control.InsertButton:SetText("Insert")
    control.RemoveButton:SetText("Remove")

    function control.SetTextError(text)
        control.RightText:SetText(text)
        control.RightText:SetTextColor(1, 0, 0)
        control.RightText:Show()
        C_Timer.After(rightTextDelay, function() control.RightText:Hide() end)
    end
    function control.SetTextSuccessful(text)
        control.RightText:SetText(text)
        control.RightText:SetTextColor(1, 1, 1)
        control.RightText:Show()
        C_Timer.After(rightTextDelay, function() control.RightText:Hide() end)
    end

    control.InsertButton:SetScript("OnClick", function()
        local input = control.SearchBox:GetText()
        if func then func(nil, "add", input, control) end
    end)
    control.RemoveButton:SetScript("OnClick", function()
        local input = control.SearchBox:GetText()
        if func then func(nil, "remove", input, control) end
    end)

    function control.SetEnable()
        control.SearchBox:Enable()
        control.InsertButton:Enable()
        control.RemoveButton:Enable()
    end
    function control.SetDisable()
        control.RightText:Hide()
        control.SearchBox:Disable()
        control.SearchBox:SetText("")
        control.InsertButton:Disable()
        control.RemoveButton:Disable()
    end

    if tooltip then
        self:CreateTooltip(control.SearchBox, tooltip.name, tooltip.text)
    end

    return control
end

return Interface