local Blizzard = HideUI:NewModule("Blizzard")
local Dispatcher
local Interface
local UIManager
local Data -- (read-only)

local MENU_NAME = "Frames"
local HEADER    = "Frames"
local MAPPINGS  = HideUI.UIMappings
local SCHEMA    = HideUI.UISchemaBlizzard
local ORDER     = HideUI.UIFrameOrderBlizzard

function Blizzard:OnInitialize()
    Dispatcher = HideUI:GetModule("Dispatcher")
    Interface  = HideUI:GetModule("Interface")
    Data       = HideUI:GetModule("Data")
    UIManager  = HideUI:GetModule("UIManager")
end

--==============================================================
-- Enable/Disable módulo
--==============================================================
function Blizzard:OnEnable()
    self.registry = {}
    self:Draw()
end

function Blizzard:OnDisable()
    self.registry = nil
end

--==============================================================
-- Refrescar datos de la UI
--==============================================================
function Blizzard:UpdateUI()
    local field
    local frame
    local setup
    for variable, _ in pairs(self.registry) do
        frame, setup = strsplit(".", variable)
        field = MAPPINGS[setup]
        Interface:SetVariableData(self.registry, variable, Data.Frames[frame][field])
    end
    -- Segundo recorrido obligatorio para deshabilitar completamente los checkbox_slider
    for variable, _ in pairs(self.registry) do
        frame, setup = strsplit(".", variable)
        field = MAPPINGS[setup]
        if field == "isEnabled" then
            Interface:SetExpandableState(self.registry, variable, Data.Frames[frame][field])
        end
    end
end

--==============================================================
-- Reacción tras interacción del usuario.
-- Ajuste de los campos de los frames y/o expandido de ventana
--==============================================================
function Blizzard:OnUpdate(variable, data)
    local frame, setup = strsplit(".", variable)
    local field = MAPPINGS[setup]
    Dispatcher:SetFrameSettings(frame, field, data)

    if field == "isEnabled" then
        Interface:SetExpandableState(Blizzard.registry, variable, data)
    end
end

--==============================================================
-- Botón de reiniciar variables a default
--==============================================================
function Blizzard:OnDefault()
    Interface:CreatePopupDialog(function(confirm)
        if confirm then
            Dispatcher:RestoreBlizzFrames()
        end
    end)
end

--==============================================================
-- Encendido/Apagado de la interfaz
--==============================================================
function Blizzard:SetEnable(enable)
    if enable then self.categoryHeader:SetEnable() else self.categoryHeader:SetDisable() end
    local sections = {self.scrollContainer:GetChildren()}
    for _, child_section in ipairs(sections) do
        if enable then child_section:SetEnable() else child_section:SetDisable() end
    end
end

function Blizzard:TurnOn()
    self:SetEnable(true)
end

function Blizzard:TurnOff()
    self:SetEnable(false)
end

--==============================================================
-- Dibujado de elementos individuales
--==============================================================
function Blizzard:Draw()
    self.subcategory, self.layout, self.frame = Interface:CreateLayoutSubcategory(UIManager.category, MENU_NAME)
    self.categoryHeader = Interface:CreateCategoryHeader(HEADER, self.frame, self.OnDefault)
    self.scrollContainer = Interface:CreateScrollContainer(self.frame, {y = -50})

    for _, frame_name in ipairs(ORDER) do
        local exists, frame = Data:IsFrameRegistered(frame_name)
        if exists then
            self:BuildSection(frame)
        end
    end

    -- Relleno entre secciones (separator)
    Interface:CreateSection(nil, "empty", self.scrollContainer, self.before, {h = 50})
end

function Blizzard:BuildSection(frame)
    local offset = self.before and -9 or -20
    local defaults = {data = self.registry, update = self.OnUpdate}
    local section = Interface:CreateSection(frame.alias, "expandable", self.scrollContainer, self.before, {y = offset})
    local settings
    local prev

    for i, desc in ipairs(SCHEMA) do
        if not (desc.frame and desc.frame ~= frame.name) then
            local variable = frame.name .. "." .. (desc.var or "")

            settings = Interface:RegisterSettings({
                name     = desc.name,
                type     = desc.type,
                variable = variable,
                tooltip  = desc.tooltip,
            }, defaults)

            prev = Interface:AddElementToSection(section, settings, prev, (i == 1) and { y = -13 } or nil)
        end
    end

    settings  = Interface:RegisterSettings({type="separator"})
    prev      = Interface:AddElementToSection(section, settings, prev, {y = -20})

    self.before = section
end