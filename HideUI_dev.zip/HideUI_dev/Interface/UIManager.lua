local UIManager = HideUI:NewModule("UIManager")
local General
local Blizzard
local Other

local MENU_NAME = "HideUI"

function UIManager:OnInitialize()
    General   = HideUI:GetModule("General")
    Blizzard  = HideUI:GetModule("Blizzard")
    Other     = HideUI:GetModule("Other")
end

function UIManager:OnEnable()
    self:RegisterAddon()

    HideUI:EnableModule("General")
    HideUI:EnableModule("Blizzard")
    HideUI:EnableModule("Other")

    self:UpdateUI()
end

function UIManager:SetEnable(enable)
    if enable then
        General:TurnOn()
        Blizzard:TurnOn()
        Other:TurnOn()
    else
        General:TurnOff()
        Blizzard:TurnOff()
        Other:TurnOff()
    end
end

function UIManager:UpdateUI()
    self.isUpdating = true

    General:UpdateUI()
    Blizzard:UpdateUI()
    Other:UpdateUI()

    self.isUpdating = false
end

function UIManager:Rebuild()
    Other:Rebuild()
end

function UIManager:RegisterAddon()
    local parent = UIParent
    local frame = CreateFrame("Frame", "HideUI" .. MENU_NAME .. "Frame", parent)
    frame.name = MENU_NAME

    local category, layout = Settings.RegisterCanvasLayoutCategory(frame, MENU_NAME)
    Settings.RegisterAddOnCategory(category)

    self.frame = frame
    self.category = category
    self.layout = layout
end