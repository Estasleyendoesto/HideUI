local Afk = HideUI:NewModule("AfkDetector", "AceEvent-3.0")
local EventManager
local Mappings
local MAP

-- Registro en el EventManager
function Afk:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
    Mappings = HideUI:GetModule("Mappings")
    MAP = Mappings:Get("afk")
    
    EventManager:RegisterDetector(MAP.name, self)
end

function Afk:EnableDetector()
    self:RegisterEvent("PLAYER_FLAGS_CHANGED", "OnAFKState")
end

function Afk:DisableDetector()
    self:UnregisterEvent("PLAYER_FLAGS_CHANGED")
end

function Afk:Check()
    self:OnAFKState()
end

function Afk:Recall()
    self:OnAFKState()
end

function Afk:OnAFKState()
    if UnitIsAFK("player") then
        EventManager:NotifyEvent(MAP.event, true)
    else
        EventManager:NotifyEvent(MAP.event, false)
    end
end