local Mount = HideUI:NewModule("MountDetector", "AceEvent-3.0")
local EventManager
local Mappings
local MAP

function Mount:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
    Mappings = HideUI:GetModule("Mappings")
    MAP = Mappings:Get("mount")

    self.isMounted = false
    EventManager:RegisterDetector(MAP.name, self)
end

function Mount:EnableDetector()
    self:RegisterEvent("UNIT_AURA", "OnMountState")
    self:RegisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED", "OnMountState")
    self:RegisterEvent("UNIT_ENTERED_VEHICLE", "OnMountState")
    self:RegisterEvent("UNIT_EXITED_VEHICLE", "OnMountState")
end

function Mount:DisableDetector()
    self:UnregisterEvent("UNIT_AURA")
    self:UnregisterEvent("PLAYER_MOUNT_DISPLAY_CHANGED")
    self:UnregisterEvent("UNIT_ENTERED_VEHICLE")
    self:UnregisterEvent("UNIT_EXITED_VEHICLE")
end

function Mount:Check()
    self:OnMountState(nil, "player")
end

function Mount:Recall()
    self.isMounted = false
    self:OnMountState(nil, "player")
end

function Mount:OnMountState(_, unit)
    if unit ~= "player" then return end
    if IsMounted() or UnitInVehicle("player") then
        if not self.isMounted then
            self.isMounted = true
            EventManager:NotifyEvent(MAP.event, true)
        end
    else
        if self.isMounted then
            self.isMounted = false
            EventManager:NotifyEvent(MAP.event, false)
        end
    end
end