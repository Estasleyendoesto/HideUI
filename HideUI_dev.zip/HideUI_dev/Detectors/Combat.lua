local Combat = HideUI:NewModule("CombatDetector", "AceEvent-3.0")
local EventManager
local Mappings
local MAP

function Combat:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
    Mappings = HideUI:GetModule("Mappings")
    MAP = Mappings:Get("combat")

    self.inCombat = false
    EventManager:RegisterDetector(MAP.name, self)
end

function Combat:EnableDetector()
    self:RegisterEvent("PLAYER_REGEN_ENABLED", "OnCombatState")
    self:RegisterEvent("PLAYER_REGEN_DISABLED", "OnCombatState")
    self:RegisterEvent("UNIT_COMBAT", "OnCombatState")
end

function Combat:DisableDetector()
    self:UnregisterEvent("PLAYER_REGEN_ENABLED")
    self:UnregisterEvent("PLAYER_REGEN_DISABLED")
    self:UnregisterEvent("UNIT_COMBAT")
end

function Combat:Check()
    -- Forzamos una evaluación rápida
    self:OnCombatState("UNIT_COMBAT", "player")
end

function Combat:Recall()
    self.inCombat = false
    self:OnCombatState("UNIT_COMBAT", "player")
end

function Combat:OnCombatState(event_name, unit)
    local enter, leave = false, false
    if event_name == "PLAYER_REGEN_ENABLED" then
        if self.inCombat then self.inCombat = false; leave = true end
    elseif event_name == "PLAYER_REGEN_DISABLED" then
        if not self.inCombat then self.inCombat = true; enter = true end
    elseif event_name == "UNIT_COMBAT" and unit == "player" then
        if UnitAffectingCombat("player") and not self.inCombat then
            self.inCombat = true; enter = true
        elseif not UnitAffectingCombat("player") and self.inCombat then
            self.inCombat = false; leave = true
        end
    end
    if enter  then EventManager:NotifyEvent(MAP.event, true)  end
    if leave  then EventManager:NotifyEvent(MAP.event, false) end
end