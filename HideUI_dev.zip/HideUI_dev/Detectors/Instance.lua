local Instance = HideUI:NewModule("InstanceDetector", "AceEvent-3.0")
local EventManager
local Mappings
local MAP

function Instance:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
    Mappings = HideUI:GetModule("Mappings")
    MAP = Mappings:Get("instance")

    self.inInstance = false
    EventManager:RegisterDetector(MAP.name, self)
end

function Instance:EnableDetector()
    self:RegisterEvent("PLAYER_ENTERING_WORLD", "OnInstance")
end

function Instance:DisableDetector()
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")
end

function Instance:Check()
    self:CheckInstance()
end

function Instance:Recall()
    self.inInstance = false
    self:CheckInstance()
end

function Instance:OnInstance()
    -- Al cambiar de instancia, forzamos reevaluación global
    EventManager:CheckEvents()
end

function Instance:CheckInstance()
    local inInst = IsInInstance()
    if inInst and not self.inInstance then
        self.inInstance = true
        EventManager:NotifyEvent(MAP.event, true)
    elseif not inInst and self.inInstance then
        self.inInstance = false
        EventManager:NotifyEvent(MAP.event, false)
    elseif not inInst and not self.inInstance then
        -- Asegura emitir false al menos una vez en arranque
        EventManager:NotifyEvent(MAP.event, false)
    end
end