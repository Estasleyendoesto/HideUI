local Data = HideUI:NewModule("Data")

---------------------------------------------------------------------
-- FRAMES TO REGISTER
---------------------------------------------------------------------
local FRAME_REGISTRY = {
    -- Chatbox
    {name = "Chatbox",                             alias = "Chat"},
    -- Frames
    {name = "PlayerFrame",                         alias = "Player"},
    {name = "TargetFrame",                         alias = "Target"},
    {name = "FocusFrame",                          alias = "Focus"},
    {name = "PetFrame",                            alias = "Pet Frame"},
    -- Misc
    {name = "MinimapCluster",                      alias = "Minimap"},
    {name = "ObjectiveTrackerFrame",               alias = "Quests"},
    {name = "BuffFrame",                           alias = "Buffs"},
    {name = "MicroMenuContainer",                  alias = "Menu"},
    {name = "BagsBar",                             alias = "Bags"},
    {name = "BattlefieldMapFrame",                 alias = "Zone Map"},
    {name = "EncounterBar",                        alias = "Dragonriding Bar"},
    {name = "PlayerCastingBarFrame",               alias = "Casting Bar"},
    {name = "MainStatusTrackingBarContainer",      alias = "Tracking Bar"},
    {name = "SecondaryStatusTrackingBarContainer", alias = "Secondary Tracking Bar"},
    {name = "StanceBar",                           alias = "Stance Bar"},
    {name = "PartyFrame",                          alias = "Party Frame"},
    -- Spell Bars
    {name = "MainMenuBar",                         alias = "Action Bar 1"},
    {name = "MultiBarBottomLeft",                  alias = "Action Bar 2"},
    {name = "MultiBarBottomRight",                 alias = "Action Bar 3"},
    {name = "MultiBarRight",                       alias = "Action Bar 4"},
    {name = "MultiBarLeft",                        alias = "Action Bar 5"},
    {name = "MultiBar5",                           alias = "Action Bar 6"},
    {name = "MultiBar6",                           alias = "Action Bar 7"},
    {name = "MultiBar7",                           alias = "Action Bar 8"},
    {name = "PetActionBar",                        alias = "Pet Action Bar"},
    {name = "ZoneAbilityFrame",                    alias = "Zone Action Bar"},
}

---------------------------------------------------------------------
-- INITIAL VALUES
---------------------------------------------------------------------
local FRAME = {
    name = "",
    alias = "",
    source = "blizzard", --blizzard, community
    isEnabled = false,
    isMouseoverEnabled = true,
    --Alpha amount
    alphaAmount = 0.5,
    combatAlphaAmount = 1,
    afkAlphaAmount = 0,
    mountAlphaAmount = 0,
    instanceAlphaAmount = 1,
    --Events
    isCombatEnabled = true,
    isAFKEnabled = true,
    isMountEnabled = true,
    isInstanceEnabled = true,
    --Cluster
    cluster = false,
}
local GLOBALS = {
    isEnabled = true,
    isCharacter = false,
    isMouseoverEnabled = true,
    mouseoverFadeInDuration = 0.3,
    mouseoverFadeOutDuration = 0.4,
    --Alpha amount
    alphaAmount = 0.5,
    combatAlphaAmount = 1,
    afkAlphaAmount = 0,
    mountAlphaAmount = 0,
    instanceAlphaAmount = 1,
    --Events
    isCombatEnabled = true,
    isAFKEnabled = true,
    isMountEnabled = true,
    isInstanceEnabled = true,
    -- Combat
    combatEndDelay = 1,
}

---------------------------------------------------------------------
-- DETAULS (FIRST LOAD)
---------------------------------------------------------------------
local DB_NAME = "HideUIDB"
local DEFAULT_PROFILE = "Default"

---------------------------------------------------------------------
-- MOD Initializer
---------------------------------------------------------------------
-- Inicializador de la base de datos
function Data:OnInitialize()
    local defaults = self:GetDefaultsInitializer()
    self.db = LibStub("AceDB-3.0"):New(DB_NAME, defaults, DEFAULT_PROFILE)
    self:RegisterMetatable()
    self:LoadProfile()

    -- self.db:ResetDB("Default") --DEBUG
    -- self.db:ResetProfile() --DEBUG
end

function Data:RegisterMetatable()
    -- Acceso a Globals y Frames como properties
    self.Globals = nil
    self.Frames = nil

    local mt = getmetatable(self) or {}
    local oldIndex   = mt.__index
    local oldNewIndex = mt.__newindex

    mt.__index = function(t, k)
        if k == "Globals" then
            return t:GetGlobals()
        end
        if k == "Frames" then
            return t:GetFrames()
        end
        if type(oldIndex) == "function" then
            return oldIndex(t, k)
        elseif type(oldIndex) == "table" then
            return oldIndex[k]
        end
        return nil
    end

     mt.__newindex = function(t, k, v)
        if k == "Globals" or k == "Frames" then
            error(("'%s' is 'read only';"):format(k))
        end
        if oldNewIndex ~= nil then
            return oldNewIndex(t, k, v)
        end
        rawset(t, k, v)
    end

    setmetatable(self, mt)
    self.__mt_registered = true
end

-- Mapeado de defaults del profile inicial
function Data:GetDefaultsInitializer()
    local frame_initializer = {}
    -- for _, frame_name in ipairs(FRAME_REGISTRY) do
    --     frame_initializer[frame_name] = self:Deepcopy(FRAME)
    --     frame_initializer[frame_name].name = frame_name
    -- end
    for _, frame in ipairs(FRAME_REGISTRY) do
        frame_initializer[frame.name] = self:Deepcopy(FRAME)
        frame_initializer[frame.name].name = frame.name
        frame_initializer[frame.name].alias = frame.alias or frame.name -- fallback
    end

    -- Chatbox extras
    frame_initializer.Chatbox.isTextModeEnabled = false
    frame_initializer.Chatbox.cluster = true

    local defaults = {
        profile = {
            globals = self:Deepcopy(GLOBALS),
            frames = frame_initializer
        }
    }
    return defaults
end

---------------------------------------------------------------------
-- Profile Methods
---------------------------------------------------------------------
-- Obtiene el nombre del perfil en formato "Jugador@Reino"
function Data:GetCharProfileName()
    return UnitName("player") .. "@" .. GetRealmName()
end

-- Verifica si el personaje tiene su propio perfil en la BD
function Data:CharHasProfile(profile_name)
    local profiles = self.db:GetProfiles()
    for _, name in ipairs(profiles) do
        if name == profile_name then
            return true
        end
    end
    return false
end

-- Devuelve si el personaje está usando un perfil propio
function Data:IsCharProfileOn()
    return self.db.profile.globals.isCharacter
end

-- Carga el perfil del personaje o usa el predeterminado si no existe o si está desactivado
function Data:LoadProfile()
    local char_profile = self:GetCharProfileName()
    local isRegistered = self:CharHasProfile(char_profile)

    if isRegistered and self:IsCharProfileOn() then
        self.db:SetProfile(char_profile)
    else
        self.db:SetProfile(DEFAULT_PROFILE)
    end
end

-- Retorna la configuración y el nombre del perfil actual
function Data:GetProfile()
    return self.db.profile, self.db:GetCurrentProfile()
end

-- Cambia entre el perfil del personaje o el perfil predeterminado
-- @param choice (boolean): true para usar el perfil del personaje, false para el predeterminado
function Data:ChangeProfile(choice)
    local char_profile = self:GetCharProfileName()
    if choice then
        self.db:SetProfile(char_profile)

        -- Si el perfil está vacío, copia los valores del perfil por defecto
        if not self.db.profile.globals or not self.db.profile.frames then
            self.db:CopyProfile(DEFAULT_PROFILE)
        end

        self.db.profile.globals.isCharacter = true
    else
        self.db.profile.globals.isCharacter = false

        self.db:SetProfile(DEFAULT_PROFILE)
        self.db.profile.globals.isEnabled = true -- Asegura que el addon siga activo
    end
end

---------------------------------------------------------------------
-- Pseudo CRUD
---------------------------------------------------------------------
-- Obtiene todos los frames del perfil actual
function Data:GetFrames()
    return self:GetProfile().frames
end

-- Obtiene los globals del perfil actual
function Data:GetGlobals()
    return self:GetProfile().globals
end

-- Actualiza un campo dentro de un frame
function Data:UpdateFrame(frame, field, input)
    if frame and field then
        local profile = self:GetProfile()
        if profile.frames[frame] then
            profile.frames[frame][field] = input
        end
    end
end

-- Actualiza un campo dentro de la configuración global
function Data:UpdateGlobals(field, input)
    if field then
        self:GetProfile().globals[field] = input
    end
end

-- Devuele true si el frame si está registrado en el perfil actual false
function Data:IsFrameRegistered(frame_name)
    local profile = frame_name and self:GetProfile()
    local frame = profile and profile.frames and profile.frames[frame_name]
    return frame ~= nil, frame
end

-- Elimina un frame del perfil actual
function Data:UnregisterFrame(name)
    local profile = name and self:GetProfile()
    if profile then
        profile.frames[name] = nil
    end
end

-- Registra un nuevo frame en la BD (por defecto para "community")
function Data:RegisterFrame(input)
    local profile = self:GetProfile()
    local copy = self:Deepcopy(FRAME)

    for k, v in pairs(input) do
        if copy[k] ~= nil then
            copy[k] = v
        end
    end

    copy.name = input.name
    copy.source = input.source or "community"

    profile.frames[input.name] = copy
end

---------------------------------------------------------------------
-- Métodos de restauración
---------------------------------------------------------------------
-- Restaura la configuración global al Default
function Data:RestoreGlobals()
    local profile = self:GetProfile()
    local copy = self:Deepcopy(GLOBALS)

    profile.globals = copy
end

-- Restaura la configuración de todos los frames iniciales al Default
function Data:RestoreBlizzFrames()
    local frames = self:GetFrames()
    for frame, data in pairs(frames) do
        if data.source == "blizzard" then
            local copy = self:Deepcopy(FRAME)
            copy.name = data.name
            copy.alias = data.alias
            frames[frame] = copy
        end
    end
    -- Para Chatbox
    frames.Chatbox.isTextModeEnabled = false
    frames.Chatbox.cluster = true
end

-- Restaura la configuración de todos los frames adicionales al Default
function Data:RestoreCommunityFrames()
    local frames = self:GetFrames()
    for frame, data in pairs(frames) do
        if data.source == "community" then
            local copy = self:Deepcopy(FRAME)
            copy.name = data.name
            copy.alias = data.alias
            copy.source = data.source
            copy.cluster = data.cluster
            frames[frame] = copy
        end
    end
end

---------------------------------------------------------------------
-- Métodos auxiliares
---------------------------------------------------------------------
-- Copia una tabla y todas las subtablas
function Data:Deepcopy(orig)
    if type(orig) ~= "table" then return orig end
    local copy = {}
    for k, v in pairs(orig) do
        copy[k] = self:Deepcopy(v) -- llamado recursivo
    end
    return copy
end