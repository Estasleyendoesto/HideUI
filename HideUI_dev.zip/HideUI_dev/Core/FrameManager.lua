-- FrameManager.lua
local FrameManager = HideUI:NewModule("FrameManager", "AceEvent-3.0", "AceTimer-3.0")
local BaseFrame
local Data

local GAME_FRAMES = {} -- name
local STATES = {
    isAFKEnabled = true,
    isMountEnabled = true,
    isCombatEnabled = true,
    isInstanceEnabled = true
}

-----------------------------
-- Timers (cancelables)
local t_findFrames
local t_mouseover

-----------------------------
-- Constantes
local FINDING_FRAMES_INTERVAL = 1.7
local FINDING_FRAMES_REPEATS  = 3
local MOUSEOVER_TIME_INTERVAL = 0.2

-----------------------------
-- Guardas
local bindingBusy = false

-- ==================================================================
-- Inicializador
-- ==================================================================
function FrameManager:OnInitialize()
    Data = HideUI:GetModule("Data")
    BaseFrame = HideUI:GetModule("BaseFrame")
end

function FrameManager:OnEnable()
    self:RegisterMessage("PLAYER_STATE_CHANGED", "EventReceiver")
    self:RegisterEvent("PLAYER_ENTERING_WORLD",  "OnInstance")

    self:StartMouseover(true)
    self:BindFrames() -- arranque rápido
end

function FrameManager:OnDisable()
    self:UnregisterMessage("PLAYER_STATE_CHANGED")
    self:UnregisterEvent("PLAYER_ENTERING_WORLD")

    self:StartMouseover(false)
    self:StopFindFrames()
    self:UnbindFrames()
end

-- ==================================================================
-- Utils
-- ==================================================================
function FrameManager:safeGetFrame(name)
    return GAME_FRAMES[name] or _G[name]
end

function FrameManager:ForEachFrame(onlyLoaded, func)
    for _, frame in pairs(GAME_FRAMES) do
        local isFrameLoaded = frame and frame.HideUI and frame.HideUI_loaded ~= false
        if frame and frame.HideUI and (not onlyLoaded or isFrameLoaded) then
            func(frame)
        end
    end
end

-- ==================================================================
-- Entrar al mundo, busca frames con reintentos y en intervalos
-- ==================================================================
function FrameManager:OnInstance()
    self:StopFindFrames()
    local repeats = 0
    t_findFrames = self:ScheduleRepeatingTimer(function()
        repeats = repeats + 1
        self:BindFrames()
        if repeats >= FINDING_FRAMES_REPEATS then
            self:StopFindFrames()
        end
    end, FINDING_FRAMES_INTERVAL)
end

-- Cancela la búsqueda activa
function FrameManager:StopFindFrames()
    if t_findFrames then
        self:CancelTimer(t_findFrames)
        t_findFrames = nil
    end
end

-- ==================================================================
-- Accionado por la interfaz, llamado por Dispatcher
-- ==================================================================
function FrameManager:GlobalSettingsUpdate(field)
    self:ForEachFrame(false, function(frame)
        self:SendSettings(frame, field)
    end)
end

function FrameManager:FrameSettingsUpdate(name, field)
    local frame = GAME_FRAMES[name]
    if not (frame and frame.HideUI) then return end

    self:SendSettings(frame, field)

    -- Extra metadata hacia el frame
    frame.HideUI:SetExtra(field)

    if field == "isEnabled" then
        frame.HideUI:Refresh()
    end
end

function FrameManager:SendSettings(frame, field)
    if field == "alphaAmount" then
        frame.HideUI:SetBaseAlpha()
    elseif string.find(field, "AlphaAmount") then
        frame.HideUI:SetSelectedAlpha(field)
    elseif STATES[field] then
        frame.HideUI:SetSelectedEvent(field)
    end
end

-- ==================================================================
-- Eventos del juego (combat, afk, etc.) 
-- Reenvía sólo a frames “listos”
-- ==================================================================
function FrameManager:EventReceiver(_, event)
    self:ForEachFrame(true, function(frame)
        frame.HideUI:EventListener(event)
    end)
end

-- ==================================================================
-- Mouseover ticker
-- ==================================================================
function FrameManager:StartMouseover(enabled)
    if enabled then
        if not t_mouseover then
            t_mouseover = self:ScheduleRepeatingTimer(function() self:OnLoop() end, MOUSEOVER_TIME_INTERVAL)
        end
    else
        if t_mouseover then
            self:CancelTimer(t_mouseover)
            t_mouseover = nil
        end
    end
end

-- Mouseover loop
function FrameManager:OnLoop()
    self:ForEachFrame(true, function(frame)
        frame.HideUI:OnMouseover()
    end)
end

-- ==================================================================
-- Añade HideUI a un frame existente, o crea un frame virtual si es 
-- un cluster (agrupación de varios frames tratados como uno solo)
-- Almacena en el registro GAME_FRAMES
-- ==================================================================
function FrameManager:InitializeFrame(frame, props, globals)
    if not frame and props.cluster then
        frame = { name = props.name } -- “cluster” virtual
    end
    if not frame then return nil end

    -- Evita recreaciones
    if frame.HideUI then return frame end

    frame.HideUI = BaseFrame:Create(frame, props, globals)
    if frame.HideUI then
        frame.HideUI_loaded = false
        frame.HideUI:OnReady()
    end
    return frame
end

function FrameManager:BindFrame(name)
    if bindingBusy then return end
    bindingBusy = true

    local props = Data.Frames[name]
    if props then
        local frame = self:InitializeFrame(self:safeGetFrame(name), props, Data.Globals)
        if frame then
            GAME_FRAMES[name] = frame
        end
    end

    bindingBusy = false
end

function FrameManager:BindFrames()
    if bindingBusy then return end
    bindingBusy = true

    local newMap  = {}
    for _, props in pairs(Data.Frames) do
        local frame = self:InitializeFrame(self:safeGetFrame(props.name), props, Data.Globals)
        if frame then
            newMap[props.name] = frame
        end
    end
    GAME_FRAMES = newMap

    bindingBusy = false
end

-- ==================================================================
-- Elimina HideUI de los frames y del registro GAME_FRAMES
-- ==================================================================
function FrameManager:DestroyFrame(frame)
    if frame and frame.HideUI then
        frame.HideUI:OnDestroy()
        frame.HideUI_loaded = nil
        frame.HideUI = nil
    end
end

function FrameManager:UnbindFrame(name)
    self:DestroyFrame(GAME_FRAMES[name])
    GAME_FRAMES[name] = nil
end

function FrameManager:UnbindFrames()
    self:ForEachFrame(false, self.DestroyFrame)
    GAME_FRAMES = {}
end