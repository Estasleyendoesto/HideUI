local FrameHelper = HideUI:NewModule("FrameHelper", "AceEvent-3.0", "AceTimer-3.0")
local EventManager

function FrameHelper:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
end

-- ===========================================================================
-- Básicos / puros (paramétricos)
-- ===========================================================================
function FrameHelper:IsLocalEnabled(props)
    return props and props.isEnabled or false
end

function FrameHelper:IsGlobalEnabled(globals)
    return globals and globals.isEnabled or false
end

function FrameHelper:Clamp01(x)
    if x == nil then return nil end
    if x < 0 then return 0 elseif x > 1 then return 1 else return x end
end

-- ===========================================================================
-- Frames
-- ===========================================================================
function FrameHelper:IsFrameValid(frame)
    local f = frame
    if f and type(f) == "table" and f.GetScript and f.HookScript and not (f.IsForbidden and f:IsForbidden()) then
        return true
    end
    return false
end

function FrameHelper:IsFrameVisible(frame)
    return frame ~= nil and frame:IsVisible() and frame:IsShown() or false
end

function FrameHelper:IsOnMouseover(frame)
    return frame ~= nil and frame:IsVisible() and frame:IsShown() and frame:IsMouseOver() or false
end

-- ===========================================================================
-- Fades / Alpha (UIFrameFade*)
-- ===========================================================================
function FrameHelper:FadeIn(frame, delay, base, target)
    if self:IsFrameVisible(frame) then
        UIFrameFadeIn(frame, delay, base, target)
    end
end

function FrameHelper:FadeOut(frame, delay, base, target)
    if self:IsFrameVisible(frame) then
        UIFrameFadeOut(frame, delay, base, target)
    end
end

-- `globals` opcional para usar sus duraciones {mouseoverFadeInDuration, mouseoverFadeOutDuration}
function FrameHelper:SelectFade(frame, delay, base, target, globals)
    base   = self:Clamp01(base)
    target = self:Clamp01(target)
    if base == nil or target == nil then return end

    if frame then UIFrameFadeRemoveFrame(frame) end

    local inDur  = globals and globals.mouseoverFadeInDuration or nil
    local outDur = globals and globals.mouseoverFadeOutDuration or nil

    if base > target then
        self:FadeOut(frame, delay or outDur, base, target)
    elseif base < target then
        self:FadeIn(frame,  delay or inDur,  base, target)
    end
end

function FrameHelper:SetAlpha(frame, amount)
    amount = self:Clamp01(amount)
    if frame then UIFrameFadeRemoveFrame(frame) end
    if self:IsFrameVisible(frame) and amount ~= nil then
        frame:SetAlpha(amount)
    end
end

-- ===========================================================================
-- Datos / Eventos (paramétricos)
-- ===========================================================================
-- Decide entre props y globals en función de props.isEnabled
function FrameHelper:GetActiveData(props, globals)
    if props and props.isEnabled then
        return props
    else
        return globals
    end
end

-- Retorna el inverso: si props.isEnabled entonces globals, si no, props (para restaurar)
function FrameHelper:GetNoActiveData(props, globals)
    if props and props.isEnabled then
        return globals
    else
        return props
    end
end

-- Calcula alpha activo con prioridad del evento
-- Requiere props/globals (para alphaAmount) y activeEvent + NO_STATE
function FrameHelper:GetAlpha(props, globals, activeEvent, NO_STATE)
    local data = self:GetActiveData(props, globals)
    local evt  = activeEvent
    local alpha = data and data.alphaAmount or 1
    if evt and evt.name ~= NO_STATE and evt.alpha ~= nil then
        alpha = evt.alpha
    end
    return alpha
end

-- Mutadores de evento sobre una tabla de estado cualquiera (por ejemplo `Initial`)
function FrameHelper:SetActiveEvent(stateTable, name, alpha)
    if not stateTable then return end
    stateTable.activeEvent = { name = name, alpha = alpha or nil }
end

function FrameHelper:GetActiveEvent(stateTable)
    return stateTable and stateTable.activeEvent or nil
end

-- ===========================================================================
-- EventManager (inyectado)
-- ===========================================================================
function FrameHelper:GetMapping(data)
    return EventManager and EventManager:GetMapping(data) or nil
end

function FrameHelper:GetEventFields()
    return EventManager and EventManager:GetMapping("fields") or nil
end

-- ===========================================================================
-- Timers
-- cancelFn: función(h, silent) -> hace CancelTimer
-- holder: tabla que contenga llaves de timers, por defecto usa las típicas
-- keys: lista opcional de nombres a cancelar
-- ===========================================================================
function FrameHelper:CancelTimers(cancelFn, holder, keys)
    if not cancelFn or not holder then return end
    local list = keys or { "_t_destroy", "_t_force", "_t_exit", "_t_refresh" }
    for _, k in ipairs(list) do
        local h = holder[k]
        if h then
            cancelFn(h, true)
            holder[k] = nil
        end
    end
end

return FrameHelper