local BaseFrame = HideUI:NewModule("BaseFrame")
local EventManager

local PLAYER_COMBAT_STATE = "PLAYER_COMBAT_STATE"
local NO_STATE = "NO_STATE"
local ENABLE_FIRST_OUT = false
local ORIGINAL_ALPHA = 1
local MOUSEOVER_REVEAL_ALPHA = 1
local ALPHA_CHANGE_DELAY = 0
local FRAME_DESTROY_DELAY = 0
local DELAY_AFTER_EVENT = 0.85

function BaseFrame:OnInitialize()
    EventManager = HideUI:GetModule("EventManager")
end

function BaseFrame:Create(uiFrame, props, globals)
    local Base = {}

    -- ACE Embeddings
    LibStub("AceEvent-3.0"):Embed(Base)
    LibStub("AceHook-3.0"):Embed(Base)
    LibStub("AceTimer-3.0"):Embed(Base)

    function Base:Initializer()

    end

    function Base:Ready()

    end

    function Base:Destroy()

    end

    Base.globals = globals
    Base.props = props
    Base.frame = uiFrame
    Base.name = props.name
    Base.eventRegistry = {}

    return Base
end

-- function BaseFrame:Embed(target)
--     LibStub("AceEvent-3.0"):Embed(target)
--     LibStub("AceHook-3.0"):Embed(target)
--     LibStub("AceTimer-3.0"):Embed(target)
-- end

--[[
function BaseFrame:Create(frame, props, globals)
    local Initial = {}
    self:Embed(Initial)

    function Initial:OnReady()
        if not self.frame.HideUI_loaded then
            self:OnCreate()
            self.frame.HideUI_loaded = true
        else
            self:OnReload()
        end
    end

    function Initial:OnCreate()
        self:Initializer()
    end

    function Initial:OnReload()
        self:Initializer()
    end

    function Initial:OnDestroy()
        self:Destroyer()
    end

    function Initial:Initializer()
        -- Solución a aquellos frames que se muestran/ocultan en medio del juego
        if self:IsFrameValid(self.frame) then
            if not self:IsHooked(self.frame, "OnShow") then
                self:SecureHookScript(self.frame, "OnShow", function() self:OnShowHandler() end)
            end
        end

        -- Actualiza opacidad inicial
        local alpha = self:GetAlpha()
        self:SelectFade(self.frame, nil, self.originalAlpha, alpha)
    end

    function Initial:Destroyer()
        if self.frame and self:IsHooked(self.frame, "OnShow") then
            self:Unhook(self.frame, "OnShow")
        end
        self:_cancelTimers()
        self._t_destroy = self:ScheduleTimer(function()
            local alpha = self:GetAlpha()
            self:SelectFade(self.frame, nil, alpha, self.originalAlpha)
        end, FRAME_DESTROY_DELAY)
    end

    -------------------------------------------------------------------------------->>>
    -- Hooks
    function Initial:OnShowHandler()
        local alpha = self:GetAlpha()
        self:SetAlpha(self.frame, alpha)
    end

    -- User settings (From Interface)
    -------------------------------------------------------------------------------->>>
    function Initial:SetBaseAlpha()
        -- Cambia .alphaAmount
        local data = self:GetActiveData()
        local active_event = self:GetActiveEvent()
        if active_event.name == NO_STATE then
            self:SetAlpha(self.frame, data.alphaAmount)
        end
    end

    function Initial:SetSelectedAlpha(field_name)
        -- Cambia el alpha desde la interfaz (slider)
        local mapping = self:GetMapping(field_name)
        local data = self:GetActiveData()
        local active_event = self:GetActiveEvent()
        local result = data[mapping.enabled] and mapping.event == active_event.name

        if result then
            self:SetAlpha(self.frame, data[field_name])
        end
    end

    function Initial:SetSelectedEvent(field_name)
        -- Según orden del usuario, fuerza la salida o reincorporación del evento seleccionado
        -- Si se reincorpora, primero comprueba si el evento se está ejecutando desde el log primario
        -- field = ejemplo: isAlphaEnabled
        local mapping = self:GetMapping(field_name)
        local event = EventManager:CreateEvent(mapping.event, false)
        local data = self:GetActiveData()

        local isEnabled = data[field_name]
        if isEnabled then
            local eventLog = EventManager:GetLog()
            for _, log in ipairs(eventLog) do
                if log.state == mapping.event then
                    event.isActive = log.isActive
                    break
                end
            end
        end

        self:EventListener(event)
    end

    function Initial:EventListener(event)
        -- Recibe el evento en crudo, comprueba si está habilitado en memoria
        -- Según su estado en memoria, admite su registro u ordena su salida

        -- Comprueba si es evento global o local
        local mapping = self:GetMapping(event.state)
        local field = mapping.enabled
        local data = self:GetActiveData()
        local isEnabled = data[field]

        -- Crea una nueva instancia del evento
        local copy = EventManager:CreateEvent(event.state, event.isActive)

        -- Si no está permitido localmente, fuerza salida y evita churn
        if isEnabled == false then
            copy.isActive = false
        end

        EventManager:EventHandler(copy, self.registry, function(e) self:OnEnterEvent(e) end)
    end

    function Initial:OnEnterEvent(event_name)
        self:EnterEvent(event_name)
    end

    function Initial:OnExitEvent(event_name)
        self:ExitEvent(event_name)
    end

    function Initial:EnterEvent(event_name)
        if event_name:match(".EXIT") then
            self:OnExitEvent(event_name)
            return
        end

        local formatted_event = EventManager:StripEventSuffix(event_name)
        local active_event    = self:GetActiveEvent()
        if formatted_event == active_event.name then return end

        local mapping     = self:GetMapping(formatted_event)
        local data        = self:GetActiveData()
        local base_alpha  = self:Clamp01(self:GetAlpha())
        local event_alpha = self:Clamp01(data[mapping.amount])

        self:SelectFade(self.frame, nil, base_alpha, event_alpha)

        -- Reafirmación con AceTimer (cancelable)
        if self._t_force then self:CancelTimer(self._t_force, true); self._t_force = nil end
        self._t_force = self:ScheduleTimer(function()
            if self.globals.isEnabled then
                local cur = self:GetActiveEvent()
                if formatted_event == cur.name then
                    self:SetAlpha(self.frame, event_alpha)
                end
            end
        end, DELAY_AFTER_EVENT)

        self:SetActiveEvent(formatted_event, event_alpha)
    end

    function Initial:ExitEvent(event_name)
        if not self:IsGlobalEnabled() then return end

        local active_event = self:GetActiveEvent()
        local base_alpha   = self:Clamp01(active_event.alpha or self:GetNoActiveData().alphaAmount)

        self:SetActiveEvent(NO_STATE)

        local alpha_delay = ALPHA_CHANGE_DELAY
        if event_name == PLAYER_COMBAT_STATE .. ".EXIT" then
            for _, event in ipairs(self.registry) do
                if event.state == PLAYER_COMBAT_STATE and event.isActive then
                    return
                end
            end
            alpha_delay = self.globals.combatEndDelay
        end

        if self._t_exit then self:CancelTimer(self._t_exit, true); self._t_exit = nil end
        self._t_exit = self:ScheduleTimer(function()
            local target_alpha = self:Clamp01(self:GetAlpha())
            self:SelectFade(self.frame, nil, base_alpha, target_alpha)
        end, alpha_delay)
    end

    function Initial:OnMouseover()
        local data = self:GetActiveData()
        local isEnabled = data.isMouseoverEnabled
        local isMouseover = self:IsOnMouseover()
        local alpha = self:GetAlpha()

        if isEnabled and isMouseover then
            if not self.fadedIn then
                self:FadeIn(self.frame, self.globals.mouseoverFadeInDuration, alpha, self.mouseoverAlpha)
                self.fadedIn = true
            end
        else
            if self.fadedIn then
                self:FadeOut(self.frame, self.globals.mouseoverFadeOutDuration, self.mouseoverAlpha, alpha)
                self.fadedIn = false
            end
        end
    end

    function Initial:Refresh()
        -- Cambia entre la configuración local o global
        -- Se almacena el antiguo alpha
        local data = self:GetNoActiveData()
        local active_event = self:GetActiveEvent()
        local old_alpha = active_event.alpha or data.alphaAmount

        -- Se reinician todos los eventos
        self:SetActiveEvent(NO_STATE, nil)
        self.registry = {}

        local fields = self:GetEventFields()
        for _, field in ipairs(fields) do
            self:SetSelectedEvent(field)
        end

        -- Se actualiza el alpha del antiguo al nuevo si NO_STATE
        if self._t_refresh then 
            self:CancelTimer(self._t_refresh, true)
            self._t_refresh = nil
        end

        self._t_refresh = self:ScheduleTimer(function()
            active_event = self:GetActiveEvent()
            if active_event.name == NO_STATE then
                self:SelectFade(self.frame, nil, old_alpha, self:GetAlpha())
            end
        end, ALPHA_CHANGE_DELAY)
    end

    function Initial:SetExtra(field_name)
        -- Aquí llegan todos los fields actualizados desde la interfaz
        -- Solo para aquellos frames con fields adicionales y únicos, ejemplo: ChatFrame.lua
    end

    -------------------------------------------------------------------------------->>>
    -- Utils
    function Initial:IsLocalEnabled()
        return self.props.isEnabled
    end

    function Initial:IsGlobalEnabled()
        return self.globals.isEnabled
    end

    function Initial:GetAlpha()
        local data = self:GetActiveData()
        local active_event = self:GetActiveEvent()

        local alpha = data.alphaAmount
        if active_event.name ~= NO_STATE then
            alpha = active_event.alpha
        end

        return alpha
    end

    function Initial:IsFrameVisible(frame)
        frame = frame or self.frame
        if frame and frame:IsVisible() and frame:IsShown() then
            return true
        else
            return false
        end
    end

    function Initial:IsOnMouseover(frame)
        frame = frame or self.frame
        if frame and frame:IsVisible() and frame:IsShown() and frame:IsMouseOver() then
            return true
        else
            return false
        end
    end

    function Initial:IsFrameValid(frame)
        local f = frame
        if f and type(f) == "table" and f.GetScript and f.HookScript and not (f.IsForbidden and f:IsForbidden()) then
            return true
        end
        return false
    end

    function Initial:FadeIn(frame, delay, base, target)
        if self:IsFrameVisible(frame) then
            UIFrameFadeIn(frame, delay, base, target)
        end
    end

    function Initial:FadeOut(frame, delay, base, target)
        if self:IsFrameVisible(frame) then
            UIFrameFadeOut(frame, delay, base, target)
        end
    end

    function Initial:SelectFade(frame, delay, base, target)
        base   = self:Clamp01(base)
        target = self:Clamp01(target)
        if base == nil or target == nil then return end

        if frame then UIFrameFadeRemoveFrame(frame) end
        if base > target then
            delay = delay or self.globals.mouseoverFadeOutDuration
            self:FadeOut(frame, delay, base, target)
        elseif base < target then
            delay = delay or self.globals.mouseoverFadeInDuration
            self:FadeIn(frame, delay, base, target)
        else
            -- no-op
        end
    end

    function Initial:SetAlpha(frame, amount)
        amount = self:Clamp01(amount)
        if frame then UIFrameFadeRemoveFrame(frame) end
        if self:IsFrameVisible(frame) and amount ~= nil then
            frame:SetAlpha(amount)
        end
    end

    function Initial:GetActiveData()
        if self.props.isEnabled then
            return self.props
        else
            return self.globals
        end
    end

    function Initial:GetNoActiveData()
        -- Para SetMode(), para recuperar el alpha anterior
        if self.props.isEnabled then
            return self.globals
        else
            return self.props
        end
    end

    function Initial:SetActiveEvent(name, alpha)
        self.activeEvent = {
            name  = name,
            alpha = alpha or nil
        }
    end

    function Initial:GetActiveEvent()
        return self.activeEvent
    end

    function Initial:GetMapping(data)
        return EventManager:GetMapping(data)
    end

    function Initial:GetEventFields()
        return EventManager:GetMapping("fields")
    end

    -- Seguridad: epoch para invalidar callbacks antiguos
    function Initial:_cancelTimers()
        if self._t_destroy then self:CancelTimer(self._t_destroy, true); self._t_destroy = nil end
        if self._t_force   then self:CancelTimer(self._t_force,   true); self._t_force   = nil end
        if self._t_exit    then self:CancelTimer(self._t_exit,    true); self._t_exit    = nil end
        if self._t_refresh then self:CancelTimer(self._t_refresh, true); self._t_refresh = nil end
    end

    function Initial:Clamp01(x)
        if x == nil then return nil end
        if x < 0 then return 0 elseif x > 1 then return 1 else return x end
    end

    Initial.registry = {}
    Initial.globals  = globals
    Initial.props    = props
    Initial.mouseoverAlpha = MOUSEOVER_REVEAL_ALPHA
    Initial.enableFirstOut = ENABLE_FIRST_OUT
    Initial.originalAlpha  = ORIGINAL_ALPHA
    Initial.activeEvent = {
        name  = NO_STATE,
        alpha = nil,
    }
    Initial.frame = frame
    Initial.name  = props.name

    -- Si es Cluster, delega responsabilidad a Cluster.lua
    if props.cluster then
        local mod = HideUI:GetModule("Cluster", true)
        return mod:Create(Initial)
    -- Si es Community, delega responsabilidad a Single.lua
    elseif props.source == "community" then
        local mod = HideUI:GetModule("Single", true)
        return mod:Create(Initial)
    else
        -- Si existe un modulo con el nombre del frame en carpeta "/Frames" , redirige
        local mod = HideUI:GetModule(Initial.name, true)
        if mod then
            return mod:Create(Initial)
        else
            return Initial
        end
    end
end
]]