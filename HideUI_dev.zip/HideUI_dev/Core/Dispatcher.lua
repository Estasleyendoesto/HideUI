local Dispatcher = HideUI:NewModule("Dispatcher", "AceEvent-3.0", "AceTimer-3.0")
local FrameManager
local UIManager
local Data

local MODULES = { "FrameManager", "EventManager" }
local t_updateUI, t_rebuild, t_refresh -- Timers (cancelables)

function Dispatcher:OnInitialize()
    Data         = HideUI:GetModule("Data")
    UIManager    = HideUI:GetModule("UIManager")
    FrameManager = HideUI:GetModule("FrameManager")
end

---------------------------------------------------------------------
-- On/Off Trigger
---------------------------------------------------------------------
function Dispatcher:OnEnable()
    self:ModulesHandler()
end

function Dispatcher:OnDisable()
    self:ModulesHandler()
end

-- Lee el flag global y ajusta módulos solo si hace falta
function Dispatcher:ModulesHandler()
    local isEnabled = Data.Globals.isEnabled and true or false
    self:SetModulesEnabled(isEnabled)
end

function Dispatcher:SetModulesEnabled(flag)
    for _, modName in ipairs(MODULES) do
        local mod = HideUI:GetModule(modName, true)
        if mod then
            local enabled = mod:IsEnabled()
            if flag and not enabled then
                HideUI:EnableModule(modName)
            elseif not flag and enabled then
                HideUI:DisableModule(modName)
            end
        end
    end
end

---------------------------------------------------------------------
-- Refresh
---------------------------------------------------------------------
-- Debounce helpers
function Dispatcher:DebouncedUpdateUI(delay)
    if t_updateUI then self:CancelTimer(t_updateUI) end
    t_updateUI = self:ScheduleTimer(function()
        UIManager:UpdateUI() --this
    end, delay or 0)
end

function Dispatcher:DebouncedRebuild(delay)
    if t_rebuild then self:CancelTimer(t_rebuild) end
    t_rebuild = self:ScheduleTimer(function()
        UIManager:Rebuild()  --this
        UIManager:UpdateUI() --this
    end, delay or 0)
end

function Dispatcher:Refresh()
    -- Desactiva y reactiva ordenadamente
    if t_refresh then self:CancelTimer(t_refresh) end
    self:SetModulesEnabled(false)
    t_refresh = self:ScheduleTimer(function()
        self:ModulesHandler()      --this
        self:DebouncedUpdateUI(0)  --UI inmediatamente tras reactivar
    end, 0.2)
end

---------------------------------------------------------------------
-- Bindings.xml
---------------------------------------------------------------------
function HideUI_Enable_Keydown()
    local isEnabled = Data.Globals.isEnabled
    Dispatcher:EnableAddon(not isEnabled)
end

-- ==================================================================
-- Triggered from General.lua (UI) and HideUI_Enable_Keydown()
-- ==================================================================
function Dispatcher:EnableAddon(choice)
    Data:UpdateGlobals("isEnabled", choice)
    UIManager:SetEnable(choice)
    self:ModulesHandler()
    self:DebouncedUpdateUI(0)
end

-- ==================================================================
-- Change Profile: Global to Chara y reversed
-- ==================================================================
function Dispatcher:ChangeProfile(choice)
    -- Secuencia: desactiva -> cambia perfil -> activa -> rebuild + update
    self:EnableAddon(false)

    -- Único temporizador y secuencia clara
    self:ScheduleTimer(function()
        Data:ChangeProfile(choice)
        self:EnableAddon(true)
        self:DebouncedRebuild(0.05)
    end, 0.15)
end

---------------------------------------------------------------------
-- Resets
---------------------------------------------------------------------
function Dispatcher:RestoreGlobals()
    Data:RestoreGlobals()
    self:Refresh()
end

function Dispatcher:RestoreBlizzFrames()
    Data:RestoreBlizzardFrames()
    self:Refresh()
end

function Dispatcher:RestoreOtherFrames()
    Data:RestoreCommunityFrames()
    self:Refresh()
end

---------------------------------------------------------------------
-- Guardado en la DB y representación del juego (to FrameManager)
---------------------------------------------------------------------
function Dispatcher:SetGlobalSettings(field, input)
    if UIManager.isUpdating then return end
    Data:UpdateGlobals(field, input)
    FrameManager:GlobalSettingsUpdate(field)
end

function Dispatcher:SetFrameSettings(frame, field, input)
    if UIManager.isUpdating then return end
    Data:UpdateFrame(frame, field, input)
    FrameManager:FrameSettingsUpdate(frame, field)
end

-- ==================================================================
-- Registro de frames
-- ==================================================================
function Dispatcher:RegisterFrame(name)
    local frameObj = _G[name]
    if frameObj and frameObj.GetName and not Data.IsFrameRegistered(name) then
        Data:RegisterFrame({ name = name })
        FrameManager:BindFrame(name)
        return true
    end
    return false
end

function Dispatcher:UnregisterFrame(name)
    local _, frame = Data.IsFrameRegistered(name)
    if frame and frame.source == "community" then
        Data:UnregisterFrame(name)
        FrameManager:UnbindFrame(name)
        return true
    end
    return false
end