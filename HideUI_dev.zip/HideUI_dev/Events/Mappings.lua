local Mappings = HideUI:NewModule("Mappings")

-- Definición única de eventos / flags / amounts / prioridades / nombres
local data = {
    {event = "PLAYER_MOUNT_STATE",    enabled = "isMountEnabled",    amount = "mountAlphaAmount"   , priority = 1, name = "mount"},
    {event = "PLAYER_AFK_STATE",      enabled = "isAFKEnabled",      amount = "afkAlphaAmount"     , priority = 2, name = "afk"},
    {event = "PLAYER_INSTANCE_STATE", enabled = "isInstanceEnabled", amount = "instanceAlphaAmount", priority = 3, name = "instance"},
    {event = "PLAYER_COMBAT_STATE",   enabled = "isCombatEnabled",   amount = "combatAlphaAmount"  , priority = 4, name = "combat"},
    -- Insertar aquí nuevos eventos...
}

local MAPPINGS = { fields = {} }

function Mappings:OnInitialize()
    self:Build()
end

function Mappings:Build()
    wipe(MAPPINGS)
    MAPPINGS.fields = {}
    for _, entry in ipairs(data) do
        MAPPINGS[entry.event]     = {enabled = entry.enabled, amount = entry.amount, priority = entry.priority, name = entry.name, event = entry.event}
        MAPPINGS[entry.enabled]   = {enabled = entry.enabled, amount = entry.amount, priority = entry.priority, name = entry.name, event = entry.event}
        MAPPINGS[entry.name]      = {enabled = entry.enabled, amount = entry.amount, priority = entry.priority, name = entry.name, event = entry.event}
        MAPPINGS[entry.priority]  = {enabled = entry.enabled, amount = entry.amount, priority = entry.priority, name = entry.name, event = entry.event}
        MAPPINGS[entry.amount]    = {enabled = entry.enabled, amount = entry.amount, priority = entry.priority, name = entry.name, event = entry.event}
    end
    for _, entry in ipairs(data) do
        if entry.enabled then
            table.insert(MAPPINGS.fields, entry.enabled)
        end
    end
end

function Mappings:Get(key) return MAPPINGS[key] end
function Mappings:GetAll() return MAPPINGS end
function Mappings:GetPriority(event_or_name) return MAPPINGS[event_or_name] and MAPPINGS[event_or_name].priority or 0 end
function Mappings:GetFields() return MAPPINGS.fields end

-- Permite añadir más entradas desde otros módulos
function Mappings:Register(entry)
    table.insert(data, entry)
    self:Build()
end