local EventRegistry = HideUI:NewModule("EventRegistry")
local REGISTRY = {}
local LOG = {}

function EventRegistry:Clear()
    wipe(REGISTRY); wipe(LOG)
end

function EventRegistry:GetAll() return REGISTRY end
function EventRegistry:GetLog() return LOG end

function EventRegistry:Exists(state)
    for _, e in ipairs(REGISTRY) do
        if e.state == state and e.isActive then return true end
    end
end

function EventRegistry:Add(event)
    if not self:Exists(event.state) then
        table.insert(REGISTRY, event)
        table.insert(LOG, event)
        return true
    end
end

function EventRegistry:Remove(state)
    for i = #REGISTRY, 1, -1 do
        local e = REGISTRY[i]
        if e.isActive and e.state == state then
            table.remove(REGISTRY, i)
            return true
        end
    end
end

function EventRegistry:GetMax()
    local max
    for _, e in ipairs(REGISTRY) do
        if not max or e.priority > max.priority then max = e end
    end
    return max
end