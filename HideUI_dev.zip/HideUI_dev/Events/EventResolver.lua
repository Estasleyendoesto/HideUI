local EventResolver = HideUI:NewModule("EventResolver")
local Mappings
local Registry

local patterns = { ".EXIT$", ".NEXT$", ".HOLD$", ".ENTER$", ".EXIT_FIRST$" }

function EventResolver:OnInitialize()
    Mappings = HideUI:GetModule("Mappings")
    Registry = HideUI:GetModule("EventRegistry")
end

function EventResolver:StripSuffix(name)
    if name == "NO_STATE" then return "NO_STATE" end
    for _, p in ipairs(patterns) do name = string.gsub(name, p, "") end
    return name
end

-- Devuelve el "sufijo" que corresponde, en vez de invocar callbacks aquí.
function EventResolver:Resolve(event, fifo)
    local reg = Registry:GetAll()
    local max = Registry:GetMax()

    if not event.isActive and #reg == 0 then
        return event.state .. ".EXIT"
    end

    if event.isActive then
        if max and event.state == max.state then
            return event.state .. ".ENTER"
        end
        return nil
    end

    if max and event.priority < max.priority then
        return max.state .. ".HOLD"
    else
        if fifo then
            if max and event.priority > max.priority then
                return event.state .. ".EXIT_FIRST"
            end
        else
            if max and event.state ~= max.state then
                return max.state .. ".NEXT"
            end
        end
    end
    return nil
end

function EventResolver:CreateEvent(event_name, isActive)
    local pr = Mappings:GetPriority(event_name)
    return { state = event_name, priority = pr or 0, isActive = isActive }
end