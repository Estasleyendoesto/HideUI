local EventManager = HideUI:NewModule("EventManager", "AceEvent-3.0")
local Mappings
local Registry
local Resolver

local DETECTORS = {}
local STATES = {"afk","combat","mount","instance"}

function EventManager:RegisterDetector(name, module)
    DETECTORS[name] = module
end

function EventManager:GetLog() return Registry:GetLog() end
function EventManager:GetPriority(x) return Mappings:GetPriority(x) end
function EventManager:StripEventSuffix(n) return Resolver:StripSuffix(n) end
function EventManager:GetMappings() return Mappings:GetAll() end
function EventManager:GetMapping(k) return Mappings:Get(k) end

local function applyRegistry(event)
    if event.isActive then
        return Registry:Add(event)
    else
        return Registry:Remove(event.state)
    end
end

function EventManager:NotifyEvent(event_name, isActive)
    local ev = Resolver:CreateEvent(event_name, isActive)
    local changed = applyRegistry(ev)
    if not changed then return end
    local suffix = Resolver:Resolve(ev, false)
    if suffix then
        self:SendMessage("PLAYER_STATE_CHANGED", { state = ev.state, priority = ev.priority, isActive = ev.isActive, resolved = suffix })
    else
        -- Aun así loggeamos el evento base
        self:SendMessage("PLAYER_STATE_CHANGED", ev)
    end
end

function EventManager:ExitStates()
    local maps = Mappings:GetAll()
    for _, key in ipairs(STATES) do
        local ev = maps[key] and maps[key].event
        if ev then self:NotifyEvent(ev, false) end
    end
end

function EventManager:CheckEvents()
    for _, det in pairs(DETECTORS) do
        if det.Check then det:Check() end
    end
end

function EventManager:Recall(event_name)
    local map = Mappings:Get(event_name); if not map then return end
    local det = DETECTORS[map.name]
    if det and det.Recall then det:Recall() end
end

function EventManager:OnInitialize()
    Mappings = HideUI:GetModule("Mappings")
    Registry = HideUI:GetModule("EventRegistry")
    Resolver = HideUI:GetModule("EventResolver")
    DETECTORS = {}
end

function EventManager:OnEnable()
    for _, det in pairs(DETECTORS) do
        if det.EnableDetector then det:EnableDetector() end
    end
    self:CheckEvents()
end

function EventManager:OnDisable()
    for _, det in pairs(DETECTORS) do
        if det.DisableDetector then det:DisableDetector() end
    end
    self:ExitStates()
    Registry:Clear()
end