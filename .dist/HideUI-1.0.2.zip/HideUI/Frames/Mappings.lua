return {
}

-- local Mappings = dofile("Interface/AddOns/TuAddon/Core/mappings.lua")
-- HideUIMappings = {...}